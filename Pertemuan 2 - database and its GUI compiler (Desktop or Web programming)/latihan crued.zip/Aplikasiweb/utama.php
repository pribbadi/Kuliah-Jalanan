<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	left:761px;
	top:20px;
	width:253px;
	height:244px;
	z-index:1;
}
-->
</style>
<div id="content">
	<blockquote>
	  <h2>Selamat Datang </h2>
	  <p>Ini adalah sebuah contoh Aplikasi Sederhana Berbasis Web, Content yang tersedia di Aplikasi ini sbb:</p>
	  <ul>
	    <li>Input Data</li>
	    <li>Hapus Data</li>
	    <li>Edit Data</li>
	    <li>About </li>
        <li>Input Gambar </li>
	    <li>Pencarian</li>
	  </ul>
	  <p>Dilengkapi dengan validasi menggunakan JavaScript dan CSS untuk Mempercantik Tampilan <br>
      Oke. Semoga Berguna dan Silakan kembangkan masih banyak kekurangan, </p>
	  <p><strong>Regards, <a href="http://www.contoh-ta.blogspot.com" target="_blank">www.contoh-ta.blogspot.com</a>  </strong></p>
  </blockquote>
</div>
