<style type="text/css">
<!--
.style1 {
	font-size: 18px;
	font-weight: bold;
}
-->
</style>
<div id="content">
	<h2>&nbsp;</h2>
	<table width="385" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr bgcolor="#8BB2D9">
        <td height="29" colspan="5"><div align="center" class="style1"><img src="image/user_comment.png" width="16" height="16">ABOUT ME ? </div></td>
      </tr>
      <tr>
        <td width="14">&nbsp;</td>
        <td width="103">&nbsp;</td>
        <td width="12">&nbsp;</td>
        <td width="243">&nbsp;</td>
        <td width="13">&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Nama</td>
        <td>:</td>
        <td>Admin</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Tutorial</td>
        <td>:</td>
        <td>Web Dinamis  + SQL </td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Telpon</td>
        <td>:</td>
        <td>089657241465</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Email</td>
        <td>:</td>
        <td>investasi.saya@gmail.com</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>WebBlog</td>
        <td>:</td>
        <td><a href="http://www.contoh-ta.blogspot.com" target="_blank">www.contoh-ta.blogspot.com</a></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
  </table>
	<p>&nbsp;</p>
	<p>	 <br/>
  </p>
</div>